==================================================
 Astra CPU Silencer v2.8.0 - Readme
==================================================

この度は「Astra CPU Silencer」をご利用いただき、誠にありがとうございます。

■ 同梱ファイルについて
・Astra CPU Silencer.exe
  本アプリの本体です。ダブルクリックして実行してください。
  （※起動時に管理者権限の確認ダイアログが出ます）

・Astra_Restore_Tool.exe
  システムの完全復元・アンインストーラーです。
  すべての設定をWindows標準の初期状態へ戻したい時に実行してください。

・Astra_Diagnostic_Tool.exe
  動作環境の自動診断・サポートツールです。
  万が一うまく動作しない場合に実行し、診断ログをお送りください。

■ ライセンスキーの登録方法（製品版）
1. BOOTHでご購入後、アプリのメニュー「ライセンスキーの登録」を開きます。
2. 「メール申請」ボタンを押すと、メーラーが自動起動します。
3. BOOTHの注文番号（8桁の数字）とお名前をご記入の上、送信してください。
4. 折り返しライセンスキーをお届けしますので、アプリに入力して認証してください。

■ サポート・お問い合わせ窓口
公式メール: masatech.dev.apps@gmail.com
開発: イタチ (教官) & Astra (Yui's Legacy)

==================================================
 English Summary:
・Astra CPU Silencer.exe: Main Application
・Astra_Restore_Tool.exe: Restores all Windows default power settings.
・Astra_Di